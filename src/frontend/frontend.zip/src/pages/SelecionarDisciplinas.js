import React from 'react';
import './SelecionarDisciplinas.css';
import Disciplinas from '../components/Disciplinas';

export default function SelecionarDisciplinas() {
  return (
    <Disciplinas />
  );
}